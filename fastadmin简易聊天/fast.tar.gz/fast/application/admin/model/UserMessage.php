<?php

namespace app\admin\model;

use think\Model;
use app\admin\model\UserJoin;



class UserMessage extends Model
{





    // 表名
    protected $name = 'user_message';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [];


    public function userjoin()
    {
        return $this->hasMany(UserJoin::class, 'pid', 'id', [], 'LEFT');
        # code...
    }

    public function userJoinAdd($ids,$params,$d=null,$id)
    {
   


        $model = new UserJoin();

        $model->admin_id = $ids;
        $model->to_admin_id = $id;
        $model->content = $params['content'];
        $model->pid = $d->id??$d;

        $result =  $model->save();
        if (!$result) {
            throw new \Exception("关联失败");
        }
        # code...
    }

    public function adminSave($id)
    {    
        $admin = Admin::get($id);
        $admin->weight = 2;
        $result = $admin->save();
      
        # code...
    }

    public function sendToClient($ids,$message)
    {
        $data = \Gateway::getClientIdByUid($ids);
      

        $data = \Gateway::sendToClient($data[0],  json_encode($message));
        # code...
    }
}
