<?php

namespace app\admin\model;

use think\Model;


class UserJoin extends Model
{

    

    

    // 表名
    protected $name = 'user_join';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    public function admin()
    {
        return $this->hasOne(Admin::class,'id','admin_id',[],'LEFT');
        # code...
    }

    public function toadmin()
    {
        return $this->hasOne(Admin::class,'id','to_admin_id',[],'LEFT');
        # code...
    }








}
