<?php

return [
    'Admin_id'    => '接收人',
    'To_admin_id' => '发送人',
    'Content'     => '内容',
    'Createtime'  => '创建时间',
    'Updatetime'  => '修改时间',
    'Status'      => '1未读,2已读',
    'Pid'         => '关联ID'
];
