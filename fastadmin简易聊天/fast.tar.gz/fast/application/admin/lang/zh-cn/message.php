<?php
                    
return [
    "Admin_id" => "添加人",
    "Content" => "内容",
    "Createtime" => "创建时间",
    "Updatetime" => "修改时间",
    "Deletetime" => "删除时间",
    "Admin.nickname" => "昵称",
    "Message" => "公告信息",
    "" => ""
];