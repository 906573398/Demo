<?php

return [
    'Admin_id'    => '接收人',
    'To_admin_id' => '发送人',
    'Content'     => '内容',
    'Createtime'  => '发送时间',
    'Updatetime'  => '查看时间'
];
