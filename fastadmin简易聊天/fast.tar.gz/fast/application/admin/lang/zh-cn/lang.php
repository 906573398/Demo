<?php

return [
    "File_name"     => "文件目录",
    "Rwa_lang_json" => "原记录",
    "Lang_json"     => "改记录",
    "Createtime"    => "修改时间",
    "Status"        => "状态",
    "Status 1"      => "成功",
    "Status 0"      => "失败"
];
