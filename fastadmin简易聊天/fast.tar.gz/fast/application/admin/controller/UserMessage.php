<?php

namespace app\admin\controller;

use think\Db;
use Exception;
use PDOException;

use think\Request;

use think\Session;
use app\admin\model\Admin;
use app\admin\model\Message;
use app\admin\model\UserJoin;
use app\common\controller\Backend;
use think\exception\ValidateException;

/**
 * 用户信息管理
 *
 * @icon fa fa-circle-o
 */
class UserMessage extends Backend
{

    /**
     * UserMessage模型对象
     * @var \app\admin\model\UserMessage
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\UserMessage;
    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */

    public function index()
    {

        // $type = input('post.type');
        // $id = input('post.id');
        // $userMessage_where = [];
        // $system_where = [];
        // if ($type) {
        //     $system_where['message.id'] = $id;
        //     $userMessage_where['user_message.id'] = $id;


        //     switch ($type) {
        //         case 2:
        //             $model = $this->model->get($id);
        //             if ($model->status <> 2) {
        //                 $model->status = 2;
        //                 $result = $model->save();
        //                 if (!$result) {
        //                     $this->error('信息查看失败');
        //                 }
        //             }
        //             break;
        //     }
        // }

        // $system = collection(Message::with('admin')->where('recipient','in', $this->auth->id)->where(['message.status' => 1])->order('id desc')
        //     ->where($system_where)->select())->toArray();
        // with('admin')
        // ->


        $system = Message::with('admin')
            ->where('recipient', 'like', '%' . $this->auth->id . '%')
            ->where(['message.status' => 1])
            ->order('id desc')

            ->select();


        $system_num = 0;
        foreach ($system as &$v) {
            $res = Message::where('id', $v['id'])->where('show_admin', 'in', $this->auth->id)->find();
            $v['is_type'] = 2;
            if (empty($res)) {
                $v['is_type'] = 1;
                $system_num++;
            }
        }



        $userMessage = Admin::where(['id' => ['<>', $this->auth->id]])->order('weight desc')->select();


        $userMessage_num = UserJoin::where('admin_id', $this->auth->id)->where('status', 1)->count();



        // if (Request::instance()->isAjax()) {
        //     return ['system' => $system, 'userMessage' => '', 'type' => $type];
        // }


        $this->view->assign([
            'system' => $system,
            'userMessage' => $userMessage,
            'system_num' => $system_num,
            'userMessage_num' => $userMessage_num
        ]);


        return $this->view->fetch();
        # code...
    }

    /**
     * 添加
     */
    public function add($ids = null)
    {
        if ($this->request->isPost()) {
            $params = $this->request->post("row/a");

            if (!$ids) {
                $ids = $params['pid'];
            }
            // $params['pid'] = $ids . ',' . $this->auth->id;
            $params['to_admin_id'] = $this->auth->id;
            $params['admin_id'] = $ids;


            if ($params) {

                $result = false;
                Db::startTrans();
                try {
                    // halt(\Gateway::getAllClientIdCount());
                    //是否采用模型验证


                    $d = $this->model->where('admin_id', $ids)->where('to_admin_id', $this->auth->id)->find();
            
                    if (!$d) {
                        $d = $this->model->where('admin_id', $this->auth->id)->where('to_admin_id', $ids)->find();
                  
                        if (!$d) {
                            $this->model->allowField(true)->save($params);
                          
                        }
                    }

                   

                    $result = $this->model->userJoinAdd($ids, $params, $d ?? $this->model->id, $this->auth->id);

                    $result = $this->model->adminSave($this->auth->id);

                    $message = [
                        'type' => 'one',
                        'content' => $params['content'],
                        'id' => $this->model->id ?? $d->id,
                        'nickname' => Admin::where(['id' => $this->auth->id])->value('nickname'),
                        'avatar'  => Admin::where(['id' => $this->auth->id])->value('avatar'),
                        'admin_id' => $this->model->admin_id ?? $d->admin_id,
                        'to_admin_id' => $this->model->to_admin_id ?? $d->to_admin_id,

                        'ids' => $this->auth->id

                    ];

                    $this->model->sendToClient($ids, $message);




                    Db::commit();
                } catch (ValidateException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (PDOException $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                } catch (Exception $e) {
                    Db::rollback();
                    $this->error($e->getMessage());
                }
                if ($result !== false) {
                    $this->success('', '', $message);
                } else {
                    $this->error(__('No rows were inserted'));
                }
            }
            $this->error(__('Parameter %s can not be empty', ''));
        }

        return $this->view->fetch();
    }

    public function query()
    {


        $data = input('post.');




        $admin = Admin::get($data['id']);
        $admin->weight = 1;
        $admin->save();
        if ($data['type'] == 2) {
            $ids = $this->model->with(['userjoin' => function ($query) {
                $query->with(['admin', 'toadmin']);
            }])->where('admin_id', $this->auth->id)->where('to_admin_id', $data['id'])->select();
            $idss = $this->model->with(['userjoin' => function ($query) {
                $query->with(['admin', 'toadmin']);

            }])->where('admin_id', $data['id'])->where('to_admin_id', $this->auth->id)->select();

            $list = array_merge($ids, $idss);

            UserJoin::where('admin_id',$this->auth->id)->where('to_admin_id',$data['id'])->update(['status'=>2]);
        //    $this->model->where('admin_id', $this->auth->id)->where('to_admin_id', $data['id'])->update(['status'=>2]);
        //   $this->model->where('admin_id', $data['id'])->where('to_admin_id', $this->auth->id)->update(['status'=>2]);
            return $this->success('', '', ['list' => $list, 'type' => 2, 'id' => $data['id']]);





        }


        $Message =  Message::with('admin')->find($data['id']);

        return $this->success('', '', ['list' => $Message, 'type' => 1, 'id' => $data['id']]);



        # code...
    }

    public function ping()
    {


        $message = ['type' => 'ping'];

        $this->model->sendToClient($this->auth->id, $message);
        return true;
        # code...
    }
}
