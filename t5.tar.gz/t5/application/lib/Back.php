<?php
namespace app\common\controller;
use think\Controller;
use think\Request;
class Index extends Controller

{
    public function index()
    {
        $request = Request::instance();
        # code...
    }


}