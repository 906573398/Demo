<?php
namespace app\common\model;
use think\Model;
class FaAuthGroup extends Model{ 
  protected $table =  "fa_auth_group"  ;
 }            