<?php
namespace app\common\model;
use think\Model;
class Kdniao extends Model{ 
  protected $table =  "fa_kdniao"  ;
 }            