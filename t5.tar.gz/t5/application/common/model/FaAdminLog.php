<?php
namespace app\common\model;
use think\Model;
class FaAdminLog extends Model{ 
  protected $table =  "fa_admin_log"  ;
 }            